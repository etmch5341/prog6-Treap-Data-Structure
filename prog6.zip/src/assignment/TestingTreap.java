package assignment;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestingTreap {
    @Test
    public void testLookup(){

    }

    @Test
    public void testInsert(){

    }

    @Test
    public void testRemove(){

    }

    @Test
    public void testSplit(){

    }

    @Test
    public void testJoin(){

    }
}
